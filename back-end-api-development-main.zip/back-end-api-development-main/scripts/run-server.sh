#!/bin/bash

# Go up one directory
cd .. 

# Run the PHP server in the background
php -S localhost:80
