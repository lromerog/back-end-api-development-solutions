<?php

	phpinfo();
	
?>