<?php

	$config = [
		"name" => "Amir"
	];

?>