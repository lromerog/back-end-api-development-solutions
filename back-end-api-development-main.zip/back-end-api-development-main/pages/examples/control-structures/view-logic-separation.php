<?php

	$title = "Control structures: view logic separation";	

	require_once 'template.html';
?>