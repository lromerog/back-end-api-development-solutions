<?php

	echo 'this is my first script';
	
?>

