<?php

   	// first way
	$animals =  array(
		'cat ', 
		'dog', 
		'sheep', 
		'snake',
		'frog'
	);

   // Second way
   $animals[]   =  'whale';
   $animals[]   =  'tiger';
   $animals[]   =  'heron';
   $animals[]   =  'ladybug';

   var_dump($animals);

    
?>
